from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse
from . models import FilesUpload
import pickle
filename = './Model/finalized_model.pkl'
loaded_model = pickle.load(open(filename, 'rb'))





# Create your views here.

def index(request):
    return render(request, "index.html")

def upload(request):
    
    if request.method == 'POST':
        file2 = request.FILES['file']
        document = FilesUpload.objects.create(file=file2)
        document.save()
        stud=FilesUpload.objects.all()
        print(stud)
        context={'form':stud}
        return render(request, "output.html",context)
    return render(request, "upload.html")