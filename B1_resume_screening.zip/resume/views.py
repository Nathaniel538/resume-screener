from django.shortcuts import render

# Create your views here.

def pg_1(request):
    return render(request, "pg_1.html")

